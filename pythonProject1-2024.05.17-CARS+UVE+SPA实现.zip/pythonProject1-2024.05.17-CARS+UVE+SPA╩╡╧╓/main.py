import numpy as np
import pandas as pd
from sklearn.cross_decomposition import PLSRegression
from sklearn.model_selection import cross_val_score
import numpy as np
from sklearn.cross_decomposition import PLSRegression
from sklearn.model_selection import cross_val_score
import numpy as np

def CARS(X, y, iteration=50, n_comps=8, cv=10):
    #iteration（迭代次数）:控制特征选择过程的迭代次数。增加迭代次数可能会导致更彻底的搜索，但代价是增加计算时间。
    #偏最小二乘回归（PLSR）模型中使用的成分数。这应根据数据的复杂性和需要在响应变量中解释的方差进行调整。
    #cv（交叉验证折数）:用于交叉验证的折数。更改此数值可以影响模型评估的稳定性和准确性。增加折数通常可以提高评估的稳健性，但同样会增加计算负担。
    N, D = X.shape
    prob = 0.8
    a = np.power((D / 2), (1 / (iteration - 1)))
    k = (np.log(D / 2)) / (iteration - 1)
    r = [round(a * np.exp(-(k * i)) * D) for i in range(1, iteration + 1)]

    weights = np.ones(D) / D
    RMSECV = []
    idWs = []

    for i in range(iteration):
        idCal = np.random.choice(np.arange(N), size=int(prob * N), replace=False)
        idW = np.random.choice(np.arange(D), size=r[i], p=weights / weights.sum(), replace=False)
        idWs.append(idW)

        X_cal = X[idCal[:, np.newaxis], idW]
        Y_cal = y[idCal]
        comp = min(n_comps, len(idW))
        pls = PLSRegression(n_components=comp)
        pls.fit(X_cal, Y_cal)

        absolute = np.abs(pls.coef_).reshape(-1)
        weights[idW] = absolute / sum(absolute)
        MSE = -cross_val_score(pls, X_cal, Y_cal, cv=cv, scoring="neg_mean_squared_error")
        RMSE = np.mean(np.sqrt(MSE))
        RMSECV.append(RMSE)

    best_index = np.argmin(RMSECV)
    W_best = idWs[best_index]
    return W_best

def UVE(X, y, n_comps=8, cv=10):
    """
    无信息变量消除算法
    :param X: 输入的光谱数据，形状为 (样本数, 变量数)
    :param y: 目标变量
    :param n_comps: PLS模型中的成分数
    :param cv: 交叉验证的折数
    :return: 被认为是信息性的变量的索引
    """
    # 偏最小二乘回归（PLSR）模型中使用的成分数。这应根据数据的复杂性和需要在响应变量中解释的方差进行调整。
    # cv（交叉验证折数）:用于交叉验证的折数。更改此数值可以影响模型评估的稳定性和准确性。增加折数通常可以提高评估的稳健性，但同样会增加计算负担。
    #其他也许也能调整，看自己理解
    N, D = X.shape  # 获取样本数和变量数
    # 初始化PLS模型
    pls = PLSRegression(n_components=n_comps)
    # 基于整个数据集拟合PLS模型
    pls.fit(X, y)
    # 计算模型的系数
    original_coefs = np.abs(pls.coef_).reshape(-1)

    # 通过交叉验证计算每个变量的稳定性
    stability_scores = np.zeros(D)
    for i in range(D):
        # 从变量集中排除当前变量
        X_reduced = np.delete(X, i, axis=1)
        # 重新拟合PLS模型
        pls_cv = PLSRegression(n_components=n_comps)
        # 计算交叉验证的MSE分数
        cv_scores = cross_val_score(pls_cv, X_reduced, y, cv=cv, scoring='neg_mean_squared_error')
        stability_scores[i] = np.mean(np.abs(cv_scores))

    # 稳定性分数与原始系数的乘积决定了变量的信息性
    informative_scores = stability_scores * original_coefs
    # 设置阈值，选择信息性变量
    threshold = np.median(informative_scores)
    informative_vars = np.where(informative_scores >= threshold)[0]

    return informative_vars

def SPA(X, max_vars=60):
    #max_vars（最大变量数）为输出的特征数量
    # 初始化参数
    n_samples, n_features = X.shape
    selected_vars = []
    remaining_vars = list(range(n_features))

    # 随机选择第一个特征
    first_var = np.random.choice(remaining_vars)
    selected_vars.append(first_var)
    remaining_vars.remove(first_var)

    # 定义正交投影函数
    def orthogonal_projection(v, V_proj):
        if V_proj.shape[1] == 0:
            return np.zeros_like(v)
        projection = V_proj @ np.linalg.pinv(V_proj.T @ V_proj) @ V_proj.T @ v
        return projection

    # 开始迭代选择其他特征
    while len(selected_vars) < max_vars and remaining_vars:
        max_residual = -np.inf
        next_var = None
        V_proj = X[:, selected_vars]

        # 在剩余的特征中找到最小化投影残差的特征
        for var in remaining_vars:
            v = X[:, var]
            proj = orthogonal_projection(v, V_proj)
            residual = np.linalg.norm(v - proj)
            if residual > max_residual:
                max_residual = residual
                next_var = var

        if next_var is not None:
            selected_vars.append(next_var)
            remaining_vars.remove(next_var)
            V_proj = np.c_[V_proj, X[:, next_var]]  # 更新投影矩阵

    return selected_vars


print('github地址：https://github.com/qinshiqisky')
print('哔站地址：https://space.bilibili.com/99731983')
print('数据还不公开，需要替换自己数据')
print('代码仅供参考')
print('你好，我的微信是18031937628，我的研究方向是以近红外光谱进行土壤养分含量的回归预测（偏向深度学习），加群以及互相交流都通过微信。')
print('加我的时候麻烦备注一下研究方向（不用备注姓名）。微信群公告有哔站地址，有视频与对应的代码，代码在置顶评论的github上下载。欢迎交流，谢谢！\n')

file_path = '集成光谱仪sg+snv-仅前五十样本.xlsx'  # 替换为您的文件路径
data = pd.read_excel(file_path)

X = data.iloc[:, 1:].values  # 第一列是标签，其余的是特征
y = data.iloc[:, 0].values
print(X.shape)
print('程序在运行，请等待···\n')


# 应用CARS算法选择特征 只使用一种方法！！！！
selected_features_indices = CARS(X, y)
# selected_features_indices = UVE(X, y)
# selected_features_indices = SPA(X)

# 获取原始特征名称
original_feature_names = data.columns[1:]
# 使用选定的特征，并将标签列添加回来
X_selected = X[:, selected_features_indices]
selected_data_with_labels = np.column_stack((y, X_selected))
# 获取选定特征的名称
selected_feature_names = original_feature_names[selected_features_indices]
# 对选定的特征索引按波段顺序进行排序
sorted_selected_features_indices = np.sort(selected_features_indices)
# 使用排序后的选定特征，并将标签列添加回来
X_selected_sorted = X[:, sorted_selected_features_indices]
selected_data_with_labels_sorted = np.column_stack((y, X_selected_sorted))
# 获取排序后选定特征的名称
sorted_selected_feature_names = original_feature_names[sorted_selected_features_indices]
# 将选定的特征及其标签保存到Excel，按照波段顺序排序
selected_data_df_band_order = pd.DataFrame(selected_data_with_labels_sorted, columns=['target'] + list(sorted_selected_feature_names))
selected_data_df_band_order.to_excel('qsk输出文件.xlsx', index=False)
print('进程处理完毕，筛选结果保存为：qsk输出文件.xlsx')
